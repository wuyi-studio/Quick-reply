// 梧藝客服小幫手（由 quick-reply/index.html 移植，原有功能保留）
    const TOTAL_PAGES = 10;
    const SLOTS_PER_PAGE = 10;
    let currentPage = 1;
    let modalPage = 1;
    let currentCategory = 'all';

    const legacyCategoryMap = {
      payment: '💙',
      cake: '🎂',
      pickup: '🚗',
      delivery: '🚗',
      flower: '💐',
      addon: '‼️'
    };

    // 預設第 1 頁常用問題與回覆資料庫 (共 10 則)
    const defaultPage1Replies = [
      {
        id: 'remit_info',
        category: '💙',
        title: '玉山銀行匯款帳號 (下單確認)',
        text: `【匯款帳號資訊】
銀行代號：808 玉山銀行
戶名：梧藝工作室
帳號：0123-940-888888

匯款完成後再麻煩告知我們「帳號後五碼」與「匯款金額」，以便核對排單，感謝您！❤️`
      },
      {
        id: 'cake_storage',
        category: '🎂',
        title: '蛋糕常溫與冷藏保存須知',
        text: `【蛋糕保存方式提醒】
我們的蛋糕皆為新鮮手作無添加防腐劑：
1. 常溫離冷藏請勿超過 40 分鐘（若天氣炎熱建議加購保冰袋）。
2. 取貨後請盡速冷藏保存，冷藏賞味期為 3 天內，冷凍可保存 7 天。`
      },
      {
        id: 'pickup_info',
        category: '🚗',
        title: '門市自取地址與營業時間',
        text: `【門市自取須知】
門市地址：台北市大安區光復南路OO巷OO號
取貨時間：週三至週日 12:00 - 19:30
抵達時向櫃檯店員報「訂購人姓名與電話」即可領取蛋糕與花束喔！`
      },
      {
        id: 'flower_care',
        category: '💐',
        title: '鮮花花束保水與照護說明',
        text: `【花束照護小提醒】
花束底部均附有保水花泥/水袋，建議取貨當天拆除包裝後將花莖剪斜角插水瓶，每日換水並放置於陰涼通風處，避免陽光直曬或冷氣出風口直吹喔！`
      },
      {
        id: 'delivery_info',
        category: '🚗',
        title: '雙北汽車外送專送說明',
        text: `【外送配送須知】
雙北地區配合 Lalamove 汽車專送，依距離跳錶計算實報實銷。
蛋糕為冷藏專送、花束會妥善固定，歡迎提供「確切外送地址與送達時間」為您試算運費喔！`
      },
      {
        id: 'addon_acc',
        category: '‼️',
        title: '餐具／造型蠟燭／數字蠟燭說明',
        text: `【餐具與蠟燭配件】
蛋糕皆附贈「單支金細蠟燭 1 支」與蛋糕刀。
若需要造型蠟燭($45/$55)、數字蠟燭($30/個)或額外盤叉餐具（2人$15/5人$30/10人$50），都可以幫您加購登記喔！`
      },
      {
        id: 'thank_confirm',
        category: '❤️',
        title: '款項核對完成＆訂單確認成立',
        text: `您好呀～已經收到您的匯款囉！款項核對無誤，訂單已為您排程排單製作！🌸
取貨日前一天會再發送提醒訊息給您，非常感謝您的支持！`
      },
      {
        id: 'burger_stock',
        category: '🍔',
        title: '現貨 🍔登記完成🍔',
        text: `您好呀～已為您保留現貨並完成登記囉！🍔 請於約定時間內前來門市取貨，謝謝您！`
      },
      {
        id: 'greeting_hello',
        category: '😊',
        title: '親切迎賓招呼語',
        text: `您好呀～歡迎光臨梧藝！🌸 請問今天有想了解蛋糕、花束或是專屬客製甜點的服務嗎？很樂意為您介紹與服務喔！`
      },
      {
        id: 'praise_thanks',
        category: '👍',
        title: '收到滿意好評感謝',
        text: `太開心聽到您的喜歡了！看到您和朋友吃得開心就是我們最大的動力與幸福🥰 期待下次再為您製作美味的蛋糕與花禮！`
      }
    ];

    // 初始化 10 頁 x 10 欄位資料結構
    let pagesData = loadPagesDataFromStorage();
    migrateOfficialDefaults();

    // ===== 官方預設回覆版本更新（擴充功能專用）=====
    // 預設內容有改版時：沒改過的官方回覆自動換成新版；自己改過或刪掉的不動；新增的官方回覆放進第一個空欄位。
    function migrateOfficialDefaults() {
      const DEFAULTS_VERSION = '1.0.1-822ceb63';
      const KEY_VER = 'wuyi_defaults_version';
      const KEY_SNAP = 'wuyi_defaults_snapshot';
      const pick = it => ({ title: it.title || '', category: it.category || '', text: it.text || '' });
      const same = (a, b) => a && b && a.title === b.title && a.category === b.category && a.text === b.text;
      try {
        if (localStorage.getItem(KEY_VER) === DEFAULTS_VERSION) return;
        let snap = null;
        try { snap = JSON.parse(localStorage.getItem(KEY_SNAP) || 'null'); } catch (e) { snap = null; }
        let updated = 0, kept = 0, added = 0;
        const findById = id => {
          for (let p = 1; p <= TOTAL_PAGES; p++) for (let s = 0; s < SLOTS_PER_PAGE; s++) {
            const it = pagesData[p][s];
            if (it && it.id === id) return { p, s, it };
          }
          return null;
        };
        const firstEmpty = () => {
          for (let p = 1; p <= TOTAL_PAGES; p++) for (let s = 0; s < SLOTS_PER_PAGE; s++) if (!pagesData[p][s]) return { p, s };
          return null;
        };
        defaultPage1Replies.forEach(d => {
          const nd = Object.assign({}, d);
          const hit = findById(d.id);
          if (hit) {
            if (same(pick(hit.it), pick(nd))) return; // 已是最新
            if (snap && same(pick(hit.it), snap[d.id])) { pagesData[hit.p][hit.s] = nd; updated++; }
            else kept++; // 使用者改過（或無法判斷）→ 保留不覆蓋
          } else if (!(snap && snap[d.id])) {
            const e = firstEmpty();
            if (e) { pagesData[e.p][e.s] = nd; added++; }
          } // 使用者刪掉的官方回覆不再自動加回
        });
        const newSnap = {};
        defaultPage1Replies.forEach(d => { newSnap[d.id] = pick(d); });
        localStorage.setItem(KEY_SNAP, JSON.stringify(newSnap));
        localStorage.setItem(KEY_VER, DEFAULTS_VERSION);
        if (updated || added) {
          savePagesDataToStorage();
          setTimeout(() => showToast(`官方預設回覆已更新 ${updated + added} 則` + (kept ? `，你改過的 ${kept} 則保留不動` : ''), '🔄'), 600);
        }
      } catch (e) {
        console.error('Defaults migrate error:', e);
      }
    }

    function loadPagesDataFromStorage() {
      let data = {};
      for (let p = 1; p <= TOTAL_PAGES; p++) {
        data[p] = [];
        for (let s = 0; s < SLOTS_PER_PAGE; s++) {
          data[p].push(null);
        }
      }

      try {
        const saved = localStorage.getItem('wuyi_100_pages_data');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && typeof parsed === 'object') {
            for (let p = 1; p <= TOTAL_PAGES; p++) {
              if (Array.isArray(parsed[p])) {
                for (let s = 0; s < SLOTS_PER_PAGE; s++) {
                  const it = parsed[p][s];
                  if (it) {
                    it.category = legacyCategoryMap[it.category] || it.category || '⭐️';
                  }
                  data[p][s] = it || null;
                }
              }
            }
            return data;
          }
        }

        // 舊格式無縫平移
        const oldSaved = localStorage.getItem('wuyi_custom_replies');
        let oldList = defaultPage1Replies;
        if (oldSaved) {
          try {
            const pOld = JSON.parse(oldSaved);
            if (Array.isArray(pOld) && pOld.length > 0) oldList = pOld;
          } catch(e){}
        }

        oldList.forEach((item, idx) => {
          const p = Math.floor(idx / 10) + 1;
          const s = idx % 10;
          if (p <= TOTAL_PAGES) {
            item.category = legacyCategoryMap[item.category] || item.category || '⭐️';
            data[p][s] = item;
          }
        });

      } catch (e) {
        console.error('Storage load error:', e);
      }

      return data;
    }

    function savePagesDataToStorage() {
      try {
        localStorage.setItem('wuyi_100_pages_data', JSON.stringify(pagesData));
      } catch (e) {
        console.error('Storage save error:', e);
      }
    }

    // 渲染主畫面 10 頁切換列 (極簡 ◀ 1..10 ▶，支援懸停拖放換頁)
    function renderMainPageNav() {
      const container = document.getElementById('mainPagePills');
      if (!container) return;

      let html = `
        <button type="button" class="btn-page-arrow" data-on-click="changeMainPage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''} title="上一頁">
          ◀
        </button>
      `;

      for (let p = 1; p <= TOTAL_PAGES; p++) {
        html += `
          <button type="button" 
                  class="page-num-btn ${p === currentPage ? 'active' : ''}" 
                  data-on-click="changeMainPage(${p})" 
                  data-on-dragover="handlePageButtonDragOver(event, ${p})"
                  title="第 ${p} 頁 (拖曳懸停可切換)">
            ${p}
          </button>
        `;
      }

      html += `
        <button type="button" class="btn-page-arrow" data-on-click="changeMainPage(${currentPage + 1})" ${currentPage === TOTAL_PAGES ? 'disabled' : ''} title="下一頁">
          ▶
        </button>
      `;

      container.innerHTML = html;
    }

    function changeMainPage(p) {
      if (p < 1 || p > TOTAL_PAGES) return;
      currentPage = p;
      renderMainPageNav();
      renderReplies();
      // 切換分頁平滑滾動至列表頂部
      const listEl = document.getElementById('repliesContainer');
      if (listEl) {
        listEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }

    // 渲染主畫面回覆卡片
    function renderReplies() {
      const container = document.getElementById('repliesContainer');
      if (!container) return;

      const searchKeyword = document.getElementById('searchInput').value.trim().toLowerCase();
      const isFiltering = (currentCategory !== 'all' || searchKeyword.length > 0);

      let itemsToRender = [];

      if (isFiltering) {
        // 搜尋或篩選時，跨全部 10 頁檢索
        for (let p = 1; p <= TOTAL_PAGES; p++) {
          pagesData[p].forEach((item, slotIdx) => {
            if (!item) return;
            const matchCategory = (currentCategory === 'all' || item.category === currentCategory);
            const matchKeyword = !searchKeyword || item.title.toLowerCase().includes(searchKeyword) || item.text.toLowerCase().includes(searchKeyword);
            if (matchCategory && matchKeyword) {
              itemsToRender.push({ ...item, pageNum: p, slotIndex: slotIdx });
            }
          });
        }

        if (itemsToRender.length === 0) {
          container.innerHTML = `
            <div style="text-align:center; padding:30px 10px; color:#94a3b8; font-size:13px; background:#fff; border-radius:8px;">
              查無相關常用回覆，建議上方直接打字或語音輸入，點擊「AI 潤飾」！
            </div>`;
          return;
        }

        container.innerHTML = itemsToRender.map(item => buildReplyCardHtml(item, item.pageNum, item.slotIndex)).join('');
      } else {
        // 一般模式：展示當前頁的 10 個欄位
        const currentSlots = pagesData[currentPage];
        let cardsHtml = '';

        for (let s = 0; s < SLOTS_PER_PAGE; s++) {
          const item = currentSlots[s];
          if (item) {
            cardsHtml += buildReplyCardHtml(item, currentPage, s);
          } else {
            // 空欄位卡片 (點擊可立即編輯填入，亦可作為拖放目標)
            cardsHtml += `
              <div class="empty-slot-card" 
                   id="emptyCard_${currentPage}_${s}" 
                   data-on-click="openEditModal(${currentPage}, ${s})"
                   data-on-dragover="handleDragOver(event)"
                   data-on-dragleave="handleDragLeave(event)"
                   data-on-drop="handleDrop(event, ${currentPage}, ${s})">
                <span style="font-size:12px; color:#94a3b8; font-weight:600;">＋ 空欄位（點擊填寫，可拖曳換位）</span>
                <button type="button" class="btn-card-edit" style="pointer-events:none; width:auto; padding:0 6px; font-size:10.5px;">
                  <span>✏️ 填寫</span>
                </button>
              </div>
            `;
          }
        }

        container.innerHTML = cardsHtml;
      }
    }

    function buildReplyCardHtml(item, pageNum, slotIdx) {
      const emoji = item.category || '⭐️';
      const titleText = escapeHtml(item.title || '常用回覆');
      // 只要標題含有 emoji 就不重複加，否則前面帶上該類別的 emoji
      const displayTitle = (item.title && /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}]/u.test(item.title))
        ? titleText
        : `<span class="reply-emoji-tag">${emoji}</span> ${titleText}`;

      return `
        <div class="reply-card"
             id="replyCard_${pageNum}_${slotIdx}"
             data-page="${pageNum}"
             data-slot="${slotIdx}"
             title="長按 3 秒可移動欄位／換頁數；也可直接滑鼠拖曳換位"
             data-on-mousedown="startLongPress(event, ${pageNum}, ${slotIdx})"
             data-on-mouseup="cancelLongPress()"
             data-on-mouseleave="cancelLongPress()"
             data-on-touchstart="handleTouchStart(event, ${pageNum}, ${slotIdx})"
             data-on-touchmove="handleTouchMove(event)"
             data-on-touchend="cancelLongPress()"
             data-on-touchcancel="cancelLongPress()"
             draggable="true"
             data-on-dragstart="handleDragStart(event, ${pageNum}, ${slotIdx})"
             data-on-dragover="handleDragOver(event)"
             data-on-dragleave="handleDragLeave(event)"
             data-on-drop="handleDrop(event, ${pageNum}, ${slotIdx})">
          <div class="reply-card-left">
            <span class="reply-card-title">${displayTitle}</span>
          </div>
          <div class="reply-card-right">
            <!-- 編輯按鈕 -->
            <button type="button" class="btn-card-edit" data-on-click="openEditModal(${pageNum}, ${slotIdx})" title="編輯文字內容">
              <span>✏️</span>
            </button>
            <!-- 複製按鈕 (防閃退安全複製) -->
            <button type="button" class="btn-main-copy" id="btnCopy_${item.id || (pageNum + '_' + slotIdx)}" data-on-click="copyTextDirect(this, \`${encodeURIComponent(item.text)}\`)">
              <span>📋 複製</span>
            </button>
            <!-- 送出按鈕 (防閃退安全呼叫 LINE OA) -->
            <button type="button" class="btn-card-send" data-on-click="sendDirectToLine(\`${encodeURIComponent(item.text)}\`)" title="貼進目前開著的 LINE 客人對話框（不會自動傳送，請自己按傳送）">
              <span>📥 貼上</span>
            </button>
          </div>
        </div>
      `;
    }

    function escapeHtml(text) {
      if (!text) return '';
      return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    // 分類篩選切換
    function selectCategory(cat, el) {
      currentCategory = cat;
      document.querySelectorAll('.cat-pill').forEach(btn => btn.classList.remove('active'));
      el.classList.add('active');
      renderReplies();
    }

    function filterReplies() {
      renderReplies();
    }

    function fillToDraft(encodedText) {
      const text = decodeURIComponent(encodedText);
      document.getElementById('draftInput').value = text;
      showToast('已填入上方編輯框，可微調後再複製');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // ================= 終極防閃退安全剪貼簿複製 (Safe Clipboard) =================
    let isCopying = false;
    let toastTimeout = null;

    function performSafeCopy(text, onSuccess) {
      if (isCopying) return;
      isCopying = true;

      const finish = () => {
        isCopying = false;
        if (typeof onSuccess === 'function') {
          try { onSuccess(); } catch (err) { console.error('Callback error:', err); }
        }
      };

      // 現代 Clipboard API
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text)
          .then(finish)
          .catch(() => {
            fallbackExecCopy(text, finish);
          });
      } else {
        fallbackExecCopy(text, finish);
      }
    }

    // 解決 iOS Safari 與 Chrome 座標超出或鍵盤彈出導致的「閃退」
    function fallbackExecCopy(text, onComplete) {
      let ta = null;
      try {
        ta = document.createElement('textarea');
        ta.value = text;
        // 關鍵：唯讀且固定在可見區域微小透明層，絕不使用 -9999px 導致 WebKit 繪圖樹崩潰
        ta.setAttribute('readonly', '');
        ta.setAttribute('contenteditable', 'false');
        ta.style.position = 'fixed';
        ta.style.top = '0';
        ta.style.left = '0';
        ta.style.width = '20px';
        ta.style.height = '20px';
        ta.style.padding = '0';
        ta.style.border = 'none';
        ta.style.outline = 'none';
        ta.style.boxShadow = 'none';
        ta.style.background = 'transparent';
        ta.style.opacity = '0.01';
        ta.style.fontSize = '16px'; // 徹底杜絕 iOS Safari 視口跳動與放大閃退
        ta.style.zIndex = '-1';

        document.body.appendChild(ta);

        if (navigator.userAgent.match(/ipad|iphone/i)) {
          const range = document.createRange();
          range.selectNodeContents(ta);
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
          ta.setSelectionRange(0, 999999);
        } else {
          ta.focus();
          ta.select();
        }

        document.execCommand('copy');
      } catch (err) {
        console.error('Safe fallback copy error:', err);
      } finally {
        if (ta && ta.parentNode) {
          ta.parentNode.removeChild(ta);
        }
        if (onComplete) onComplete();
      }
    }

    // 防閃退複製按鈕
    function copyTextDirect(btn, encodedText) {
      const text = decodeURIComponent(encodedText);
      performSafeCopy(text, () => {
        if (btn) {
          btn.classList.add('copied');
          btn.innerHTML = '<span>✓ 已複製</span>';
          setTimeout(() => {
            btn.classList.remove('copied');
            btn.innerHTML = '<span>📋 複製</span>';
          }, 1500);
        }
        showToast('已複製！請直接在官方 LINE 對話框 貼上發送');
      });
    }

    // 貼上按鈕：把文字貼進 chat.line.biz 目前開著的對話框（只貼上，不會自動傳送）
    function sendDirectToLine(encodedText) {
      const text = decodeURIComponent(encodedText);
      window.WuyiPaste.pasteToLine(text);
    }

    function copyDraftText() {
      const text = document.getElementById('draftInput').value.trim();
      if (!text) {
        showToast('請先輸入或語音錄入文字再複製！', '⚠️');
        return;
      }
      performSafeCopy(text, () => {
        showToast('已複製編輯框內容！請至 LINE 貼上');
      });
    }

    // ================= 編輯單筆 Modal 邏輯 =================
    let editingPage = 1;
    let editingSlot = 0;

    function openEditModal(pageNum, slotIdx) {
      editingPage = pageNum;
      editingSlot = slotIdx;

      const item = pagesData[pageNum][slotIdx] || { title: '', category: 'payment', text: '' };
      document.getElementById('editReplyId').value = `${pageNum}_${slotIdx}`;
      document.getElementById('editReplyTitle').value = item.title || '';
      document.getElementById('editReplyCat').value = item.category || 'payment';
      document.getElementById('editReplyText').value = item.text || '';

      const modalTitle = document.querySelector('#editModal .modal-title');
      if (modalTitle) {
        modalTitle.textContent = `✏️ 編輯回覆：第 ${pageNum} 頁 - 第 ${slotIdx + 1} 欄位`;
      }

      document.getElementById('editModal').classList.add('show');
    }

    function closeEditModal() {
      document.getElementById('editModal').classList.remove('show');
    }

    function closeEditModalOnBg(e) {
      if (e.target.id === 'editModal') closeEditModal();
    }

    function saveEditReply() {
      const title = document.getElementById('editReplyTitle').value.trim();
      const cat = document.getElementById('editReplyCat').value;
      const text = document.getElementById('editReplyText').value.trim();

      if (!title && !text) {
        // 清空該欄位
        pagesData[editingPage][editingSlot] = null;
        savePagesDataToStorage();
        renderMainPageNav();
        renderReplies();
        closeEditModal();
        showToast('已清空該欄位');
        return;
      }

      pagesData[editingPage][editingSlot] = {
        id: `slot_${editingPage}_${editingSlot}`,
        category: cat || '⭐️',
        title: title || `回覆 P${editingPage}-${editingSlot + 1}`,
        text: text
      };

      savePagesDataToStorage();
      renderMainPageNav();
      renderReplies();
      closeEditModal();
      showToast('✅ 已成功儲存修改！');
    }

    // ================= 常用回覆管理 Modal (10 頁 x 10 欄位) =================
    function openManageModal() {
      modalPage = currentPage;
      document.getElementById('manageModal').classList.add('show');
      renderModalPageSelector();
      renderModalTenSlots();
      renderModalList();
    }

    function closeManageModal() {
      document.getElementById('manageModal').classList.remove('show');
    }

    function closeModalOnBg(e) {
      if (e.target.id === 'manageModal') closeManageModal();
    }

    function switchModalTab(tab) {
      ['batch', 'single', 'list'].forEach(t => {
        document.getElementById(`tabBtn${t.charAt(0).toUpperCase() + t.slice(1)}`).classList.toggle('active', t === tab);
        document.getElementById(`tabContent${t.charAt(0).toUpperCase() + t.slice(1)}`).classList.toggle('active', t === tab);
      });
      if (tab === 'batch') {
        renderModalPageSelector();
        renderModalTenSlots();
      }
      if (tab === 'list') renderModalList();
    }

    function renderModalPageSelector() {
      const container = document.getElementById('modalPageSelector');
      if (!container) return;

      let html = '';
      for (let p = 1; p <= TOTAL_PAGES; p++) {
        html += `
          <button type="button" class="modal-page-btn ${p === modalPage ? 'active' : ''}" data-on-click="changeModalPage(${p})">
            ${p}
          </button>
        `;
      }
      container.innerHTML = html;

      const lbl = document.getElementById('editingPageLabel');
      if (lbl) lbl.textContent = `第 ${modalPage} 頁（欄位 #1 ~ #10）`;
    }

    function changeModalPage(p) {
      modalPage = p;
      renderModalPageSelector();
      renderModalTenSlots();
    }

    function renderModalTenSlots() {
      const container = document.getElementById('tenSlotsContainer');
      if (!container) return;

      const catOptions = ['💐', '🌹', '🎂', '🍔', '🔥', '🚗', '⭐️', '‼️', '❓', '😊', '👍', '💙', '❤️'].map(e => ({ value: e, label: e }));

      const currentSlots = pagesData[modalPage];
      let html = '';

      for (let i = 0; i < SLOTS_PER_PAGE; i++) {
        const item = currentSlots[i] || { title: '', category: '⭐️', text: '' };
        html += `
          <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:7px 9px; display:flex; flex-direction:column; gap:4px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <span style="font-size:11.5px; font-weight:700; color:#1e293b;">📌 欄位 #${i + 1} (頁碼 P${modalPage})</span>
              <select id="slotCat_${i}" class="modal-input" style="width:auto; height:24px; padding:0 6px; font-size:11px;">
                ${catOptions.map(opt => `<option value="${opt.value}" ${item.category === opt.value ? 'selected' : ''}>${opt.label}</option>`).join('')}
              </select>
            </div>
            <input type="text" id="slotTitle_${i}" class="modal-input" placeholder="標題 (例：玉山銀行匯款帳號)" value="${escapeHtml(item.title || '')}" style="height:25px; font-size:12px;">
            <textarea id="slotText_${i}" class="modal-textarea" placeholder="回覆內文內容..." style="height:50px; font-size:12px; margin:0;">${escapeHtml(item.text || '')}</textarea>
          </div>
        `;
      }

      container.innerHTML = html;
    }

    function saveCurrentModalPageSlots() {
      for (let i = 0; i < SLOTS_PER_PAGE; i++) {
        const titleEl = document.getElementById(`slotTitle_${i}`);
        const catEl = document.getElementById(`slotCat_${i}`);
        const textEl = document.getElementById(`slotText_${i}`);

        if (titleEl && textEl) {
          const title = titleEl.value.trim();
          const text = textEl.value.trim();
          const cat = catEl ? catEl.value : '⭐️';

          if (title || text) {
            pagesData[modalPage][i] = {
              id: `slot_${modalPage}_${i}`,
              category: cat,
              title: title || `回覆 P${modalPage}-${i + 1}`,
              text: text
            };
          } else {
            pagesData[modalPage][i] = null;
          }
        }
      }

      savePagesDataToStorage();
      renderMainPageNav();
      renderReplies();
      closeManageModal();
      showToast(`🎉 成功儲存第 ${modalPage} 頁的 10 個欄位！`);
    }

    function clearCurrentModalPageSlots() {
      if (!confirm(`確定要清空第 ${modalPage} 頁的所有欄位嗎？`)) return;
      for (let i = 0; i < SLOTS_PER_PAGE; i++) {
        const t = document.getElementById(`slotTitle_${i}`);
        const txt = document.getElementById(`slotText_${i}`);
        if (t) t.value = '';
        if (txt) txt.value = '';
      }
      showToast(`已清空第 ${modalPage} 頁欄位表格（點下方儲存即生效）`);
    }

    // 單筆新增（自動放入第一個空卡位）
    function saveSingleReply() {
      const title = document.getElementById('newReplyTitle').value.trim();
      const cat = document.getElementById('newReplyCat').value;
      const text = document.getElementById('newReplyText').value.trim();

      if (!title || !text) {
        showToast('請填寫標題與回覆內文！', '⚠️');
        return;
      }

      // 找尋第一個空位
      let targetP = -1, targetS = -1;
      for (let p = 1; p <= TOTAL_PAGES; p++) {
        for (let s = 0; s < SLOTS_PER_PAGE; s++) {
          if (!pagesData[p][s]) {
            targetP = p; targetS = s;
            break;
          }
        }
        if (targetP !== -1) break;
      }

      if (targetP === -1) {
        showToast('全部 100 個欄位皆已滿！請先編輯或清空部分欄位', '⚠️');
        return;
      }

      pagesData[targetP][targetS] = {
        id: `slot_${targetP}_${targetS}`,
        category: cat || '⭐️',
        title: title,
        text: text
      };

      savePagesDataToStorage();
      currentPage = targetP;
      renderMainPageNav();
      renderReplies();
      closeManageModal();
      document.getElementById('newReplyTitle').value = '';
      document.getElementById('newReplyText').value = '';
      showToast(`✅ 已自動存入第 ${targetP} 頁 - 欄位 #${targetS + 1}！`);
    }

    function renderModalList() {
      const listEl = document.getElementById('modalRepliesList');
      if (!listEl) return;

      let allItems = [];
      for (let p = 1; p <= TOTAL_PAGES; p++) {
        pagesData[p].forEach((item, slotIdx) => {
          if (item) allItems.push({ ...item, page: p, slot: slotIdx });
        });
      }

      if (allItems.length === 0) {
        listEl.innerHTML = '<div style="font-size:12px; color:#94a3b8; text-align:center; padding:15px;">目前尚無設定任何回覆</div>';
        return;
      }

      listEl.innerHTML = allItems.map(item => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; border:1px solid #cbd5e1; padding:6px 9px; border-radius:6px;">
          <div style="font-size:12px; color:#1e293b; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:320px;">
            <b style="color:var(--primary-dark);">P${item.page}-${item.slot + 1}</b> ${escapeHtml(item.title)}
          </div>
          <button type="button" data-on-click="deleteReplyByCoordinate(${item.page}, ${item.slot})" style="background:#fee2e2; color:#ef4444; border:none; border-radius:4px; padding:2px 7px; font-size:10.5px; font-weight:700; cursor:pointer;">
            刪除
          </button>
        </div>
      `).join('');
    }

    function deleteReplyByCoordinate(p, s) {
      if (!confirm(`確定要刪除 P${p}-${s + 1} 這則回覆嗎？`)) return;
      pagesData[p][s] = null;
      savePagesDataToStorage();
      renderMainPageNav();
      renderReplies();
      renderModalList();
      showToast('已刪除該欄位回覆');
    }

    function resetToDefaultReplies() {
      if (!confirm('確定要恢復預設官方範本嗎？所有頁面自訂內容將被重置')) return;
      localStorage.removeItem('wuyi_100_pages_data');
      localStorage.removeItem('wuyi_custom_replies');
      pagesData = loadPagesDataFromStorage();
      currentPage = 1;
      renderMainPageNav();
      renderReplies();
      renderModalPageSelector();
      renderModalTenSlots();
      renderModalList();
      showToast('已恢復官方預設範本');
    }

    // AI 潤飾功能
    function polishWithAI() {
      const input = document.getElementById('draftInput');
      const raw = input.value.trim();
      if (!raw) {
        showToast('請先輸入或語音錄入簡短文字！', '⚠️');
        return;
      }
      showToast('✨ AI 正在潤飾溫柔客服口吻...', '⏳');

      setTimeout(() => {
        let polished = `您好呀～🌸\n${raw}\n\n您再麻煩幫我們確認一下喔，有任何需要調整或疑問隨時跟我們說，謝謝您！❤️`;
        input.value = polished;
        showToast('✨ 已完成 AI 潤飾！可按「複製」或「貼上」');
      }, 300);
    }

    // 語音輸入 Web Speech API
    let recognition = null;
    let isRecording = false;

    function toggleVoiceInput() {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        hideVoiceButton('此環境不支援語音辨識，請改用打字');
        return;
      }

      if (!recognition) {
        recognition = new SpeechRecognition();
        recognition.lang = 'zh-TW';
        recognition.continuous = false;
        recognition.interimResults = false;

        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript;
          const input = document.getElementById('draftInput');
          input.value = input.value ? (input.value + ' ' + transcript) : transcript;
          showToast('🎤 語音轉文字完成！可點擊 AI 潤飾');
        };

        recognition.onend = () => { isRecording = false; updateVoiceUI(); };
        recognition.onerror = (ev) => {
          isRecording = false; updateVoiceUI();
          const err = ev && ev.error;
          if (err === 'not-allowed' || err === 'service-not-allowed' || err === 'audio-capture') {
            hideVoiceButton('側邊欄無法使用麥克風，語音輸入已隱藏，請改用打字');
          } else if (err && err !== 'no-speech' && err !== 'aborted') {
            showToast('語音辨識失敗，請再試一次或改用打字', '⚠️');
          }
        };
      }

      if (isRecording) {
        recognition.stop();
        isRecording = false;
      } else {
        try { recognition.start(); isRecording = true; }
        catch (e) { isRecording = false; hideVoiceButton('側邊欄無法使用語音輸入，請改用打字'); }
      }
      updateVoiceUI();
    }

    function hideVoiceButton(msg) {
      const btn = document.getElementById('btnVoice');
      if (btn) btn.style.display = 'none';
      try { localStorage.setItem('wuyi_voice_disabled', '1'); } catch (e) {}
      if (msg) showToast(msg, '⚠️');
    }
    if (!(window.SpeechRecognition || window.webkitSpeechRecognition) || localStorage.getItem('wuyi_voice_disabled') === '1') {
      const vb = document.getElementById('btnVoice');
      if (vb) vb.style.display = 'none';
    }

    function updateVoiceUI() {
      const btn = document.getElementById('btnVoice');
      const txt = document.getElementById('voiceText');
      if (isRecording) {
        btn.classList.add('recording');
        txt.textContent = '聆聽中...停止';
      } else {
        btn.classList.remove('recording');
        txt.textContent = '語音輸入';
      }
    }

    // ================= 訂單報價試算器邏輯 =================
    const quoteState = {
      hasFlower390: false,
      customFlowerPrice: 0,
      hasBag: false,
      cakePrice: 0,
      hasIceBag: false,
      addons: { u2: 0, u5: 0, u10: 0, c45: 0, c55: 0 }
    };

    function toggleQuoteCollapse() {
      document.getElementById('quoteCollapse').classList.toggle('open');
    }

    function toggleFlower() {
      quoteState.hasFlower390 = !quoteState.hasFlower390;
      document.getElementById('btnFlower').classList.toggle('active', quoteState.hasFlower390);
      if (quoteState.hasFlower390) document.getElementById('flowerCustomPrice').value = '';
      calcQuote();
    }

    function onFlowerCustomInput() {
      const val = parseInt(document.getElementById('flowerCustomPrice').value, 10);
      quoteState.customFlowerPrice = (!isNaN(val) && val > 0) ? val : 0;
      if (quoteState.customFlowerPrice > 0) {
        quoteState.hasFlower390 = false;
        document.getElementById('btnFlower').classList.remove('active');
      }
      calcQuote();
    }

    function toggleBag() {
      quoteState.hasBag = !quoteState.hasBag;
      document.getElementById('btnBag').classList.toggle('active', quoteState.hasBag);
      calcQuote();
    }

    function setCakePreset(price) {
      if (quoteState.cakePrice === price) {
        quoteState.cakePrice = 0;
        document.getElementById('cakeCustomPrice').value = '';
      } else {
        quoteState.cakePrice = price;
        document.getElementById('cakeCustomPrice').value = price;
      }
      updateCakeBtnUI();
      calcQuote();
    }

    function onCakeCustomInput() {
      const val = parseInt(document.getElementById('cakeCustomPrice').value, 10);
      quoteState.cakePrice = (!isNaN(val) && val > 0) ? val : 0;
      updateCakeBtnUI();
      calcQuote();
    }

    function updateCakeBtnUI() {
      document.getElementById('cp760').classList.toggle('active', quoteState.cakePrice === 760);
      document.getElementById('cp1030').classList.toggle('active', quoteState.cakePrice === 1030);
      document.getElementById('cp1060').classList.toggle('active', quoteState.cakePrice === 1060);
    }

    function cycleAddon(key, unitPrice, label) {
      quoteState.addons[key] = (quoteState.addons[key] + 1) % 6; // 0 ~ 5 循環
      const count = quoteState.addons[key];
      const btnMap = { u2: 'btnU2', u5: 'btnU5', u10: 'btnU10', c45: 'btnC45', c55: 'btnC55' };
      const btn = document.getElementById(btnMap[key]);

      if (count === 0) {
        btn.classList.remove('active');
        btn.textContent = `${label} +$${unitPrice}`;
      } else {
        btn.classList.add('active');
        btn.textContent = `${label} x${count} +$${count * unitPrice}`;
      }
      calcQuote();
    }

    function toggleIceBag() {
      quoteState.hasIceBag = !quoteState.hasIceBag;
      document.getElementById('btnIce').classList.toggle('active', quoteState.hasIceBag);
      calcQuote();
    }

    function getQuoteSummary() {
      let items = [];
      let total = 0;

      let fPrice = quoteState.hasFlower390 ? 390 : quoteState.customFlowerPrice;
      if (fPrice > 0) { items.push(`花束$${fPrice}`); total += fPrice; }
      if (quoteState.hasBag) { items.push(`提袋$40`); total += 40; }
      if (quoteState.cakePrice > 0) { items.push(`蛋糕$${quoteState.cakePrice}`); total += quoteState.cakePrice; }

      const addonConfigs = {
        u2: { name: '2人餐具', price: 15 },
        u5: { name: '5人餐具', price: 30 },
        u10: { name: '10人餐具', price: 50 },
        c45: { name: '蠟燭', price: 45 },
        c55: { name: '蠟燭', price: 55 }
      };

      Object.keys(quoteState.addons).forEach(k => {
        const cnt = quoteState.addons[k];
        if (cnt > 0) {
          const p = cnt * addonConfigs[k].price;
          items.push(cnt === 1 ? `${addonConfigs[k].name}$${p}` : `${addonConfigs[k].name}x${cnt}$${p}`);
          total += p;
        }
      });

      if (quoteState.hasIceBag) { items.push(`保冰袋$100`); total += 100; }

      return { items, total };
    }

    function calcQuote() {
      const { total } = getQuoteSummary();
      document.getElementById('totalBadge').textContent = `加總 $${total}`;
    }

    function buildQuoteText() {
      const { items, total } = getQuoteSummary();
      const list = items.length > 0 ? items.join('\n') + `\n總共$${total}` : `總共$${total}`;
      return `您好呀～\n幫您加總一下\n\n${list}\n\n您再麻煩確認一下對不對喔\n謝謝您`;
    }

    function copyQuoteText() {
      const { items } = getQuoteSummary();
      if (items.length === 0) {
        showToast('請先選擇或輸入至少一項品項金額！', '⚠️');
        return;
      }
      const text = buildQuoteText();
      performSafeCopy(text, () => {
        showToast('已複製報價文案！請直接貼到官方 LINE 對話框');
      });
    }

    function pasteQuoteText() {
      const { items } = getQuoteSummary();
      if (items.length === 0) {
        showToast('請先選擇或輸入至少一項品項金額！', '⚠️');
        return;
      }
      window.WuyiPaste.pasteToLine(buildQuoteText());
    }

    function pasteDraftText() {
      const text = document.getElementById('draftInput').value.trim();
      if (!text) {
        showToast('請先輸入或語音錄入文字再貼上！', '⚠️');
        return;
      }
      window.WuyiPaste.pasteToLine(text);
    }

    function resetQuote() {
      quoteState.hasFlower390 = false;
      quoteState.customFlowerPrice = 0;
      quoteState.hasBag = false;
      quoteState.cakePrice = 0;
      quoteState.hasIceBag = false;
      quoteState.addons = { u2: 0, u5: 0, u10: 0, c45: 0, c55: 0 };

      document.getElementById('btnFlower').classList.remove('active');
      document.getElementById('flowerCustomPrice').value = '';
      document.getElementById('btnBag').classList.remove('active');
      document.getElementById('cakeCustomPrice').value = '';
      updateCakeBtnUI();
      document.getElementById('btnIce').classList.remove('active');

      ['u2', 'u5', 'u10', 'c45', 'c55'].forEach(k => {
        const btnMap = { u2: 'btnU2', u5: 'btnU5', u10: 'btnU10', c45: 'btnC45', c55: 'btnC55' };
        const labelMap = { u2: '2人餐具 +$15', u5: '5人餐具 +$30', u10: '10人餐具 +$50', c45: '蠟燭 $45', c55: '蠟燭 $55' };
        const b = document.getElementById(btnMap[k]);
        b.classList.remove('active');
        b.textContent = labelMap[k];
      });

      calcQuote();
      showToast('已重設報價金額');
    }

    function showToast(msg, icon = '✅') {
      const t = document.getElementById('toast');
      document.getElementById('toastIcon').textContent = icon;
      document.getElementById('toastMsg').textContent = msg;
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 2000);
    }

    // ================= 長按 3 秒移動欄位 / 換頁數 ＆ 拖曳排序 =================
    let longPressTimer = null;
    let longPressCard = null;
    let touchStartX = 0;
    let touchStartY = 0;
    let movingPage = 1;
    let movingSlot = 0;
    let draggedCoord = null;

    function startLongPress(e, pageNum, slotIdx) {
      if (e.target.closest('button') || e.target.closest('a') || e.target.closest('input') || e.target.closest('textarea')) {
        return;
      }

      cancelLongPress();
      longPressCard = { page: pageNum, slot: slotIdx };

      const cardEl = document.getElementById(`replyCard_${pageNum}_${slotIdx}`);
      if (cardEl) {
        cardEl.classList.add('pressing');
      }

      // 3秒 (3000ms) 長按計時
      longPressTimer = setTimeout(() => {
        cancelLongPress();
        if (navigator.vibrate) {
          try { navigator.vibrate([60, 50, 60]); } catch (err) {}
        }
        openMoveModal(pageNum, slotIdx);
      }, 3000);
    }

    function cancelLongPress() {
      if (longPressTimer) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
      }
      document.querySelectorAll('.reply-card.pressing').forEach(el => el.classList.remove('pressing'));
    }

    function handleTouchStart(e, pageNum, slotIdx) {
      if (e.touches && e.touches[0]) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
      startLongPress(e, pageNum, slotIdx);
    }

    function handleTouchMove(e) {
      if (!longPressTimer) return;
      if (e.touches && e.touches[0]) {
        const dist = Math.hypot(e.touches[0].clientX - touchStartX, e.touches[0].clientY - touchStartY);
        if (dist > 14) {
          cancelLongPress();
        }
      }
    }

    // 移動與換頁 Modal 控制
    function openMoveModal(p, s) {
      movingPage = p;
      movingSlot = s;

      const item = pagesData[p]?.[s];
      if (!item) return;

      const previewEl = document.getElementById('moveItemPreview');
      if (previewEl) {
        const emoji = item.category || '⭐️';
        previewEl.innerHTML = `<span class="reply-emoji-tag">${emoji}</span> ${escapeHtml(item.title || '常用回覆')}`;
      }

      const locEl = document.getElementById('moveSourceLocation');
      if (locEl) {
        locEl.textContent = `第 ${p} 頁 - 欄位 #${s + 1}`;
      }

      const pageSelect = document.getElementById('targetPageSelect');
      if (pageSelect) {
        let html = '';
        for (let i = 1; i <= TOTAL_PAGES; i++) {
          html += `<option value="${i}" ${i === p ? 'selected' : ''}>第 ${i} 頁</option>`;
        }
        pageSelect.innerHTML = html;
      }

      updateTargetSlotOptions();
      document.getElementById('moveModal')?.classList.add('show');
    }

    function updateTargetSlotOptions() {
      const pageSelect = document.getElementById('targetPageSelect');
      const slotSelect = document.getElementById('targetSlotSelect');
      if (!pageSelect || !slotSelect) return;

      const targetP = parseInt(pageSelect.value, 10);
      let html = '';
      for (let s = 0; s < SLOTS_PER_PAGE; s++) {
        const item = pagesData[targetP]?.[s];
        let desc = '(空欄位)';
        if (item && item.title) {
          desc = `${item.category || ''} ${item.title}`;
          if (desc.length > 15) desc = desc.slice(0, 15) + '...';
        }
        const isCurrent = (targetP === movingPage && s === movingSlot);
        html += `<option value="${s}" ${s === movingSlot && targetP !== movingPage ? 'selected' : ''}>
          #${s + 1} ${escapeHtml(desc)} ${isCurrent ? '👈 目前' : ''}
        </option>`;
      }
      slotSelect.innerHTML = html;
    }

    function closeMoveModal() {
      document.getElementById('moveModal')?.classList.remove('show');
    }

    function closeMoveModalOnBg(e) {
      if (e.target.id === 'moveModal') closeMoveModal();
    }

    // 快捷相對微調順序
    function moveSlotRelative(direction) {
      const targetSlot = movingSlot + direction;
      if (targetSlot < 0 || targetSlot >= SLOTS_PER_PAGE) {
        showToast(direction < 0 ? '已經在最上方了！' : '已經在最下方了！', '⚠️');
        return;
      }

      const temp = pagesData[movingPage][targetSlot];
      pagesData[movingPage][targetSlot] = pagesData[movingPage][movingSlot];
      pagesData[movingPage][movingSlot] = temp;

      savePagesDataToStorage();
      movingSlot = targetSlot;
      renderMainPageNav();
      renderReplies();
      openMoveModal(movingPage, movingSlot);
      showToast(`已移動至第 ${movingSlot + 1} 格！`);
    }

    function moveSlotToExtremes(pos) {
      const targetSlot = (pos === 'top') ? 0 : (SLOTS_PER_PAGE - 1);
      if (targetSlot === movingSlot) {
        showToast(pos === 'top' ? '已經在最前格了！' : '已經在最後格了！', '⚠️');
        return;
      }

      const item = pagesData[movingPage].splice(movingSlot, 1)[0];
      if (pos === 'top') {
        pagesData[movingPage].unshift(item);
      } else {
        pagesData[movingPage].push(item);
      }

      savePagesDataToStorage();
      movingSlot = targetSlot;
      renderMainPageNav();
      renderReplies();
      openMoveModal(movingPage, movingSlot);
      showToast(pos === 'top' ? '已移到最前格！' : '已移到最後格！');
    }

    // 指定跨頁/跨格移動 (互換 或 插入)
    function executeMove(action) {
      const targetPage = parseInt(document.getElementById('targetPageSelect').value, 10);
      const targetSlot = parseInt(document.getElementById('targetSlotSelect').value, 10);

      if (targetPage === movingPage && targetSlot === movingSlot) {
        showToast('目標位置與目前位置相同！', '⚠️');
        return;
      }

      const srcItem = pagesData[movingPage][movingSlot];

      if (action === 'swap') {
        const destItem = pagesData[targetPage][targetSlot];
        pagesData[targetPage][targetSlot] = srcItem;
        pagesData[movingPage][movingSlot] = destItem;
      } else if (action === 'insert') {
        if (targetPage === movingPage) {
          pagesData[movingPage].splice(movingSlot, 1);
          pagesData[movingPage].splice(targetSlot, 0, srcItem);
        } else {
          pagesData[movingPage][movingSlot] = null;
          pagesData[targetPage].splice(targetSlot, 0, srcItem);
          pagesData[targetPage].length = SLOTS_PER_PAGE;
        }
      }

      savePagesDataToStorage();
      currentPage = targetPage;
      renderMainPageNav();
      renderReplies();
      closeMoveModal();
      showToast(`🎉 成功移動至第 ${targetPage} 頁 - 欄位 #${targetSlot + 1}！`);
    }

    // HTML5 滑鼠拖曳排序
    function handleDragStart(e, pageNum, slotIdx) {
      draggedCoord = { page: pageNum, slot: slotIdx };
      e.dataTransfer.effectAllowed = 'move';
      const card = document.getElementById(`replyCard_${pageNum}_${slotIdx}`);
      card?.classList.add('dragging');
    }

    function handleDragOver(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const target = e.currentTarget;
      if (target && !target.classList.contains('drag-over')) {
        target.classList.add('drag-over');
      }
    }

    function handleDragLeave(e) {
      e.currentTarget?.classList.remove('drag-over');
    }

    function handleDrop(e, targetPage, targetSlot) {
      e.preventDefault();
      e.currentTarget?.classList.remove('drag-over');
      document.querySelectorAll('.reply-card.dragging').forEach(el => el.classList.remove('dragging'));

      if (!draggedCoord) return;
      const srcP = draggedCoord.page;
      const srcS = draggedCoord.slot;
      if (srcP === targetPage && srcS === targetSlot) return;

      const temp = pagesData[targetPage][targetSlot];
      pagesData[targetPage][targetSlot] = pagesData[srcP][srcS];
      pagesData[srcP][srcS] = temp;

      savePagesDataToStorage();
      currentPage = targetPage;
      renderMainPageNav();
      renderReplies();
      showToast(`🎉 成功調換順序至第 ${targetPage} 頁 - 欄位 #${targetSlot + 1}！`);
      draggedCoord = null;
    }

    function handlePageButtonDragOver(e, p) {
      e.preventDefault();
      if (currentPage !== p) {
        changeMainPage(p);
      }
    }

    // ================= 分割畫面模式切換 (靠右顯示 / 靠下顯示) =================
    function setSplitMode(mode, silent) {
      document.body.classList.remove('mode-right', 'mode-bottom');
      document.body.classList.add(`mode-${mode}`);

      const btnR = document.getElementById('btnSplitRight');
      const btnB = document.getElementById('btnSplitBottom');
      if (btnR) btnR.classList.toggle('active', mode === 'right');
      if (btnB) btnB.classList.toggle('active', mode === 'bottom');

      try {
        localStorage.setItem('wuyi_split_mode', mode);
      } catch (e) {}

      if (mode === 'bottom') {
        // 靠下堆疊模式時自動展開試算器，方便橫向雙欄同步操作
        const qc = document.getElementById('quoteCollapse');
        if (qc && !qc.classList.contains('open')) {
          qc.classList.add('open');
        }
      }

      if (!silent) showToast(mode === 'right' ? '已切換為：📐 靠右顯示 (適合 Chrome 左右分割)' : '已切換為：📐 靠下顯示 (適合 Chrome 上下堆疊)');
    }

    // ================= 自訂回覆資料備份與還原 =================
    function exportBackupJson() {
      try {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(pagesData, null, 2));
        const a = document.createElement('a');
        a.href = dataStr;
        a.download = `wuyi_custom_replies_backup_${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        showToast('✅ 備份檔下載完成！您已編輯的所有資料已妥善儲存');
      } catch (err) {
        showToast('匯出失敗：' + err.message, '⚠️');
      }
    }

    function triggerImportJson() {
      const input = document.getElementById('backupFileInput');
      if (input) input.click();
    }

    function handleImportFile(event) {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = JSON.parse(e.target.result);
          if (imported && typeof imported === 'object') {
            pagesData = imported;
            savePagesDataToStorage();
            renderMainPageNav();
            renderReplies();
            renderModalPageSelector();
            renderModalTenSlots();
            renderModalList();
            showToast('🎉 成功還原備份資料！所有回覆已載入');
          } else {
            showToast('檔案格式不符，請確認是有效的備份檔', '⚠️');
          }
        } catch (err) {
          showToast('讀取檔案失敗：' + err.message, '⚠️');
        }
      };
      reader.readAsText(file);
      event.target.value = '';
    }


    // 初始化渲染與讀取模式 (預設為適合上下堆疊分割的靠下模式)
    const savedMode = localStorage.getItem('wuyi_split_mode') || 'right';
    setSplitMode(savedMode, true);
    renderMainPageNav();
    renderReplies();
  
