// 梧藝客服小幫手：chat.line.biz 內容腳本
// 只負責把文字「填進」對話輸入框並把游標放到最後。
// 絕不點擊傳送鈕、絕不送出 Enter / Command+Enter 等按鍵，傳送由使用者自己按。
(function () {
  'use strict';
  if (window.__wuyiQR && window.__wuyiQR.version === 1) return; // 避免重複注入

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && Number(cs.opacity) > 0.01;
  }

  function usableTextarea(el) {
    return isVisible(el) && !el.disabled && !el.readOnly;
  }

  const CE_SEL = '[contenteditable="true"], [contenteditable=""], [contenteditable="plaintext-only"]';
  const SEARCH_RE = /搜尋|搜索|検索|search|filter|篩選/i;

  function isSearchBox(el) {
    const hint = [el.getAttribute('placeholder'), el.getAttribute('aria-label'), el.getAttribute('name'), el.id, el.className]
      .filter(Boolean).join(' ');
    return SEARCH_RE.test(hint) || !!el.closest('[role="search"]');
  }

  function isEditable(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el instanceof HTMLTextAreaElement) return usableTextarea(el);
    return el.isContentEditable && isVisible(el);
  }

  // 記住使用者最後點過的輸入框（LINE 對話框通常就是它）
  let lastFocused = null;
  document.addEventListener('focusin', e => {
    const el = e.target;
    if ((el instanceof HTMLTextAreaElement || (el instanceof Element && el.isContentEditable)) && !isSearchBox(el)) lastFocused = el;
  }, true);

  function kindOf(el) { return el instanceof HTMLTextAreaElement ? 'textarea' : 'contenteditable'; }

  function findInput() {
    const tas = Array.from(document.querySelectorAll('textarea')).filter(usableTextarea);
    // 1) placeholder 含「傳送 / Enter / send」的 textarea（LINE 聊天輸入框）
    const byPh = tas.filter(t => /傳送|传送|送信|Enter|send/i.test(t.getAttribute('placeholder') || ''));
    if (byPh.length) return { el: byPh[byPh.length - 1], kind: 'textarea' };
    // 2) 最後一次被點過、且還在畫面上的輸入框
    if (lastFocused && isEditable(lastFocused)) return { el: lastFocused, kind: kindOf(lastFocused) };
    // 3) 其餘可見的 textarea / contenteditable（排除搜尋框），取畫面上最下方的那個（對話輸入框通常在最下面）
    const ces = Array.from(document.querySelectorAll(CE_SEL))
      .filter(el => isVisible(el) && !(el.parentElement && el.parentElement.closest(CE_SEL)));
    const cands = tas.concat(ces).filter(el => !isSearchBox(el));
    if (!cands.length) return null;
    cands.sort((a, b) => a.getBoundingClientRect().bottom - b.getBoundingClientRect().bottom);
    const el = cands[cands.length - 1];
    return { el, kind: kindOf(el) };
  }

  function insertIntoTextarea(el, text) {
    const existing = el.value || '';
    const appended = existing.trim().length > 0;
    const next = appended ? existing.replace(/\n+$/, '') + '\n' + text : text;
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, next); // 用原生 setter，讓 React/Vue 偵測到變更
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.focus();
    try { el.setSelectionRange(next.length, next.length); } catch (e) {}
    el.scrollTop = el.scrollHeight;
    return { appended };
  }

  function insertIntoContentEditable(el, text) {
    const existing = (el.innerText || '').replace(/\u200b/g, '');
    const appended = existing.trim().length > 0;
    el.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false); // 游標移到最後
    sel.removeAllRanges();
    sel.addRange(range);
    const toInsert = appended ? '\n' + text : text;
    let ok = false;
    try { ok = document.execCommand('insertText', false, toInsert); } catch (e) { ok = false; }
    if (!ok) {
      el.appendChild(document.createTextNode(toInsert));
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: toInsert }));
    }
    return { appended };
  }

  function insert(text) {
    const found = findInput();
    if (!found) return { ok: false, reason: 'input-not-found' };
    const r = found.kind === 'textarea' ? insertIntoTextarea(found.el, text) : insertIntoContentEditable(found.el, text);
    return { ok: true, kind: found.kind, appended: r.appended };
  }

  window.__wuyiQR = { version: 1, insert, findInput };

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg || msg.type !== 'WUYI_QR_INSERT') return;
      try {
        sendResponse(insert(String(msg.text || '')));
      } catch (e) {
        sendResponse({ ok: false, reason: 'error', error: String(e && e.message || e) });
      }
    });
  }
})();
