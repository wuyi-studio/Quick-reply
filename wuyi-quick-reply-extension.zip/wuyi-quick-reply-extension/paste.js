// 把文字貼進 chat.line.biz 目前開著的客人對話框（只貼上，絕不自動傳送）。
(function () {
  'use strict';
  const LINE_URL_RE = /^https:\/\/chat\.line\.biz\//;
  const NOT_FOUND_MSG = '找不到 LINE 對話框，請先打開客人對話（文字已複製，可手動貼上）';

  function toast(msg, icon) {
    if (typeof window.showToast === 'function') window.showToast(msg, icon);
  }

  function copyFallback(text) {
    if (typeof window.performSafeCopy === 'function') {
      window.performSafeCopy(text, () => {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
  }

  async function getActiveLineTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && LINE_URL_RE.test(tab.url)) return tab;
    return null;
  }

  function sendInsert(tabId, text) {
    return chrome.tabs.sendMessage(tabId, { type: 'WUYI_QR_INSERT', text });
  }

  // 對指定分頁貼上；內容腳本還沒載入（擴充功能安裝前就開著的分頁）時，先注入再重試。
  async function pasteToTab(tabId, text) {
    let res;
    try {
      res = await sendInsert(tabId, text);
    } catch (e) {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      res = await sendInsert(tabId, text);
    }
    return res || { ok: false, reason: 'no-response' };
  }

  async function pasteToLine(text) {
    if (!text) return { ok: false, reason: 'empty' };
    let res = { ok: false, reason: 'no-line-tab' };
    try {
      const tab = await getActiveLineTab();
      if (tab) res = await pasteToTab(tab.id, text);
    } catch (e) {
      console.warn('[梧藝] 貼上失敗', e);
      res = { ok: false, reason: 'error', error: String(e && e.message || e) };
    }
    if (res.ok) {
      toast(res.appended ? '已接在對話框原有文字後面（換行），請確認後自己按「傳送」' : '已貼進 LINE 對話框，請確認後自己按「傳送」', '📥');
    } else {
      copyFallback(text);
      toast(NOT_FOUND_MSG, '⚠️');
    }
    return res;
  }

  window.WuyiPaste = { pasteToLine, pasteToTab, getActiveLineTab };
})();
